# database-SSW
This is for assignment 5 of CIS4301. I am using python to show a db on a website. 
